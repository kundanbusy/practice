package com.wf.apps.interviewApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
