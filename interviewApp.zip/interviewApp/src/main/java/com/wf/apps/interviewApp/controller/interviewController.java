package com.wf.apps.interviewApp.controller;

import java.time.LocalDateTime;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wf.apps.interviewApp.dto.interviewAttendees;
import com.wf.apps.interviewApp.dto.interviewConvertor;
import com.wf.apps.interviewApp.dto.interviewCountDto;
import com.wf.apps.interviewApp.dto.interviewDto;
import com.wf.apps.interviewApp.entity.interview;
import com.wf.apps.interviewApp.exceptions.customExceptions;
import com.wf.apps.interviewApp.exceptions.userAlreadyAddedExcecption;
import com.wf.apps.interviewApp.service.interviewService;
import com.wf.apps.interviewApp.service.userService;

@RestController
public class interviewController {
	
	@Autowired
	userService userservice;
	@Autowired
	interviewService interviewservice;	

	//interview ops
	
	@PostMapping("/interviews")
	public ResponseEntity<interviewDto> addInterview(@Valid @RequestBody interviewDto interviewDto,BindingResult result) {
		
		if(result.hasErrors())
		{
			customExceptions exception=new customExceptions();
			for(FieldError err:result.getFieldErrors())
			{
				if(exception.getErrorMessage()==null) {
				exception.setErrorCode(err.getCode());
				exception.setErrorMessage(err.getDefaultMessage());
				}
				else
				{
					exception.setErrorCode(exception.getErrorCode()+" || "+err.getCode());
					exception.setErrorMessage(exception.getErrorMessage()+" || "+err.getDefaultMessage());					
				}
			}
			exception.setErrorTimeStamp(LocalDateTime.now());
			throw exception;
		}
		return new ResponseEntity<interviewDto>(interviewservice.saveInterview(interviewDto),HttpStatus.OK);
	}
	
	@PostMapping("/addAttendees")
	public interview addAttendees(@Valid @RequestBody interviewAttendees interviewAttendees,BindingResult result)
	{
		if(result.hasErrors())
		{
			customExceptions exception=new customExceptions();
			for(FieldError err:result.getFieldErrors())
			{
				if(exception.getErrorMessage()==null) {
				exception.setErrorCode(err.getCode());
				exception.setErrorMessage(err.getDefaultMessage());
				}
				else
				{
					exception.setErrorCode(exception.getErrorCode()+" || "+err.getCode());
					exception.setErrorMessage(exception.getErrorMessage()+" || "+err.getDefaultMessage());					
				}
			}
			exception.setErrorTimeStamp(LocalDateTime.now());
			throw exception;
		}
		
		if(interviewservice.isAttendeeAddedToInterview(interviewAttendees))
			throw new customExceptions(LocalDateTime.now(),"Users Exception","One or more of the user Ids in the request are already added to the "+interviewAttendees.getInterviewName()+" Interview");
		return interviewservice.addAttendees(interviewAttendees);
	}
	
	@GetMapping("/getAttendeesByInterviewName/{name}")
	public interviewDto getAttendees(@PathVariable("name") String intName)
	{
		return interviewservice.getAttendees(intName);
	}
	
	@GetMapping("/searchInterview/{interviewName}/{interviewerName}")
	public interviewDto searchInterview(@PathVariable("interviewName") String interviewName,@PathVariable("interviewerName") String interviewerName) {
		return interviewservice.getInterview(interviewName, interviewerName);
	}
	
	@DeleteMapping("/removeInterview/{interviewName}/{interviewerName}")
	public interviewDto removeInterview(@PathVariable("interviewName") String interviewName,@PathVariable("interviewerName") String interviewerName) {
		
		if(searchInterview(interviewName,interviewerName)==null)
			throw new customExceptions(LocalDateTime.now(),"Interview Exception", interviewName+" Interview already Deleted");
		return interviewservice.deleteInterview(interviewName, interviewerName);
	}
	
	@GetMapping("/interviews")
	public List<interviewDto> searchAllInterviews()
	{
		return interviewservice.getAllInterviews();
	}
	
	@GetMapping("/modifyStatus/{interviewName}/{status}")
	public interviewDto modifyInterviewStatus(@PathVariable("interviewName") String interviewName,@PathVariable("status") String status)
	{
		return interviewservice.modifyStatus(interviewName,status);
	}
	
	@GetMapping("/interviewCount")
	public interviewCountDto getInterviewCount()
	{
		return interviewservice.getInterviewCount();
	}
}
