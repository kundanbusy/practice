package com.wf.apps.interviewApp.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wf.apps.interviewApp.dto.interviewAttendees;
import com.wf.apps.interviewApp.dto.interviewConvertor;
import com.wf.apps.interviewApp.dto.interviewCountDto;
import com.wf.apps.interviewApp.dto.interviewDto;
import com.wf.apps.interviewApp.entity.interview;
import com.wf.apps.interviewApp.entity.user;
import com.wf.apps.interviewApp.repository.interviewRepository;
import com.wf.apps.interviewApp.repository.userRepository;

@Service
@Transactional
public class interviewServiceImpl implements interviewService{

	@Autowired
	interviewRepository interviewrepository;
	@Autowired
	userRepository userrepository;
	
	@Override
	public interviewDto saveInterview(interviewDto interviewDto) {
		// TODO Auto-generated method stub
		interview interview=interviewConvertor.interviewDtoToInterviewConvertor(interviewDto);
		interview.setDate(LocalDate.now());
		interview.setTime(LocalTime.now());
		interviewrepository.save(interview); 
		return interviewConvertor.interviewToInterviewDtoConvertor(interview);
		
	}

	@Override
	public interview addAttendees(interviewAttendees interviewAttendees) {
		// TODO Auto-generated method stub
		System.out.println("fuck "+interviewAttendees.getInterviewName());
		System.out.println("fuck "+interviewAttendees.getUserIds().toString());
		user user;		
		interview interview=interviewrepository.findByInterviewName(interviewAttendees.getInterviewName());
		List<user> interviewusers=interview.getUsers();
		if(interviewusers==null)
			interviewusers=new ArrayList<user>();
		for(int id:interviewAttendees.getUserIds())
		{
			user=userrepository.findById(id).orElse(null);
			interviewusers.add(user);
		}
		interview.setUsers(interviewusers);
		interviewrepository.save(interview);
		return interview;
	}

	@Override
	public interviewDto getAttendees(String intName) {
		// TODO Auto-generated method stub
		return interviewConvertor.interviewToInterviewDtoConvertor(interviewrepository.findByInterviewName(intName));
	}

	@Override
	public interviewDto getInterview(String technology, String interviewor) {
		// TODO Auto-generated method stub	
		if(interviewrepository.findByInterviewNameAndInterviewerName(technology, interviewor)==null)
			return null;
		return interviewConvertor.interviewToInterviewDtoConvertor(interviewrepository.findByInterviewNameAndInterviewerName(technology, interviewor));
	}

	@Override
	public interviewDto deleteInterview(String technology, String interviewor) {
		// TODO Auto-generated method stub
		interviewDto interviewDto=getInterview(technology, interviewor);
		interviewrepository.deleteByInterviewNameAndInterviewerName(technology, interviewor);
		return interviewDto;
	}

	@Override
	public List<interviewDto> getAllInterviews() {
		// TODO Auto-generated method stub
		List<interviewDto> intList=new ArrayList<interviewDto>();
		for(interview item:interviewrepository.findAll()) {
			intList.add(interviewConvertor.interviewToInterviewDtoConvertor(item));
		}
		return intList;
	}

	@Override
	public interviewDto modifyStatus(String interviewName, String status) {
		// TODO Auto-generated method stub
		interview interview=interviewrepository.findByInterviewName(interviewName);
		interview.setInterviewStatus(status);
		return interviewConvertor.interviewToInterviewDtoConvertor(interview);
	}

	@Override
	public interviewCountDto getInterviewCount() {
		// TODO Auto-generated method stub
		interviewCountDto countDto=new interviewCountDto();
		countDto.setNoOfInterviews(interviewrepository.interviewCount());
		return countDto;
	}

	@Override
	public boolean isAttendeeAddedToInterview(interviewAttendees interviewAttendees) {
		// TODO Auto-generated method stub
		interview interview=interviewrepository.findByInterviewName(interviewAttendees.getInterviewName());
		List<Integer> attendees=interviewAttendees.getUserIds();
		boolean found=false;
		if(interview!=null)
		{
			List<user> users=interview.getUsers();
			for(user user:users) {
				for(int id:attendees) {
					if(id==user.getUserid())
						found=true;
				}
				
			}
			
		}
		return found;
	}

}
