package com.wf.apps.interviewApp.service;

import java.util.List;

import com.wf.apps.interviewApp.dto.userDto;
import com.wf.apps.interviewApp.entity.user;

public interface userService {
	
	public user addUserService(userDto userDto);
	public user deleteUserService(Long mobile);
	public List<user> getAllUsersService();
	//public boolean isUserPresent(Long mobile);
	public boolean isUserPresent(Long mobile);

}
