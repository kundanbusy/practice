package com.wf.apps.interviewApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.wf.apps.interviewApp.entity.interview;

@Repository
public interface interviewRepository extends JpaRepository<interview, Integer>{
	
	public interview findByInterviewName(String name);
	public interview findByInterviewNameAndInterviewerName(String technology,String interviewor);
	public Integer deleteByInterviewNameAndInterviewerName(String technology,String interviewor);
	@Query("SELECT COUNT(x) from interview x")
	public Integer interviewCount();
}
