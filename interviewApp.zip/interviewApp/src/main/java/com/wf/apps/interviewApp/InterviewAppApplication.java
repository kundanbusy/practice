package com.wf.apps.interviewApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterviewAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterviewAppApplication.class, args);
	}

}
