package com.wf.apps.interviewApp.dto;

import com.wf.apps.interviewApp.entity.user;

public class userConvertor {
	
	public static user userDtoToUserConverted(userDto userDto)
	{
		user user=new user();
		user.setEmail(userDto.getEmailDto());
		user.setFirstName(userDto.getFirstNameDto());
		user.setLastName(userDto.getLastNameDto());
		user.setMobile(userDto.getMobileDto());
		return user;
	}
	
	public static userDto userToUserDtoConverter(user user)
	{
		userDto userDto=new userDto();
		userDto.setUserId(user.getUserid());
		userDto.setEmailDto(user.getEmail());
		userDto.setFirstNameDto(user.getFirstName());
		userDto.setLastNameDto(userDto.getLastNameDto());
		userDto.setMobileDto(user.getMobile());
		
		return userDto;
	}

}
