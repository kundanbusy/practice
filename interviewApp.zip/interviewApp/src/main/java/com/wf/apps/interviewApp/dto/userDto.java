package com.wf.apps.interviewApp.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import lombok.Data;

@Data
public class userDto {
	
	private Integer userId;
	@NotBlank(message = "First Name should'nt be blank.")
	@Length(min = 5,max = 30,message = "First Name should be min 5 and max 30 characters.")
	private String firstNameDto;
	@NotBlank(message = "Last Name should'nt be blank.")
	@Length(min = 3,max = 25,message = "Last Name should be min 3 and max 25 characters.")
	private String lastNameDto;
	@NotBlank(message = "email should'nt be blank")
	@Email(message = "Enter appropriate email id.")
	private String emailDto;
	@NotBlank(message = "cell no should'nt be blank.")
	@Length(min = 10,max = 10,message = "cell no should be exactly a size of 10 integers from [0-10) <mathematial inclusive/exclusive> not starting with 0.")
	private Long mobileDto;
}
