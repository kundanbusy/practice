package com.wf.apps.interviewApp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wf.apps.interviewApp.dto.userConvertor;
import com.wf.apps.interviewApp.dto.userDto;
import com.wf.apps.interviewApp.entity.user;
import com.wf.apps.interviewApp.repository.userRepository;

@Service
@Transactional
public class userServiceImpl implements userService{

	@Autowired
	userRepository userrepository;
	
	@Override
	public user addUserService(userDto userDto) {
		// TODO Auto-generated method stub
		user user=userConvertor.userDtoToUserConverted(userDto);
		return userrepository.save(user);
	}

	@Override
	public user deleteUserService(Long mobile) {
		// TODO Auto-generated method stub
		user user=userrepository.findByMobile(mobile);
		userrepository.deleteByMobile(mobile);
		return user;
	}

	@Override
	public List<user> getAllUsersService() {
		// TODO Auto-generated method stub
		return userrepository.findAll();
	}

	@Override
	public boolean isUserPresent(Long mobile) {
		// TODO Auto-generated method stub
		if(userrepository.findByMobile(mobile)==null)
			return false;
		return true;
	}



}
